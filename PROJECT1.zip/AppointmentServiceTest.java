package test;
import main.AppointmentService;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;
import main.Appointment;
class AppointmentServiceTest {

	 public void testAddAppointment() {
	        AppointmentService appointmentService = new AppointmentService();
	        Date appointmentDate = new Date();
	        String appointmentId = "12345";
	        String description = "Meeting";

	        Appointment appointment = new Appointment(appointmentId, appointmentDate, description);
	        appointmentService.addAppointment(appointment);

	        assertEquals(appointment, appointmentService.getAppointment(appointmentId));
	    }

	    @Test
	    public void testDeleteAppointment() {
	        AppointmentService appointmentService = new AppointmentService();
	        Date appointmentDate = new Date();
	        String appointmentId = "12345";
	        String description = "Meeting";

	        Appointment appointment = new Appointment(appointmentId, appointmentDate, description);
	        appointmentService.addAppointment(appointment);
	        appointmentService.deleteAppointment(appointmentId);

	        assertNull(appointmentService.getAppointment(appointmentId));
	    }
}
