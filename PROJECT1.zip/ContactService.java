	import java.util.HashMap;
	import java.util.Map;

	public class ContactService {
	    private final Map<String, Contact> contacts;

	    public ContactService() {
	        this.contacts = new HashMap<>();
	    }

	    public void addContact(Contact contact) {
	        contacts.put(contact.getContactId(), contact);
	    }

	    public void deleteContact(String contactId) {
	        contacts.remove(contactId);
	    }

	    public void updateContactField(String contactId, String fieldName, String value) {
	        Contact contact = contacts.get(contactId);
	        if (contact != null) {
	            switch (fieldName) {
	                case "firstName":
	                    contact.setFirstName(value);
	                    break;
	                case "lastName":
	                    contact.setLastName(value);
	                    break;
	                case "phone":
	                    contact.setPhone(value);
	                    break;
	                case "address":
	                    contact.setAddress(value);
	                    break;
	                default:
	                    // Handle unsupported field
	                    throw new IllegalArgumentException("Unsupported field: " + fieldName);
	            }
	        }
	    }

	    public Contact getContact(String contactId) {
	        return contacts.get(contactId);
	    }
	}
