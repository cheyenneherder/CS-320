package main;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks;

    public TaskService() {
        this.tasks = new HashMap<>();
    }

    public void addTask(Task task) {
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    public void updateTaskField(String taskId, String fieldName, String value) {
        Task task = tasks.get(taskId);
        if (task != null) {
            switch (fieldName) {
                case "name":
                    task.setName(value);
                    break;
                case "description":
                    task.setDescription(value);
                    break;
                default:
                    // Handle unsupported
                    throw new IllegalArgumentException("Unsupported field: " + fieldName);
            }
        }
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
