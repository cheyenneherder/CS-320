package test;
import main.TaskService;
import main.Task;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");

        taskService.addTask(task);

        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    public void testDeleteTask() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");

        taskService.addTask(task);
        taskService.deleteTask("12345");

        assertNull(taskService.getTask("12345"));
    }

    @Test
    public void testUpdateTaskField() {
        TaskService taskService = new TaskService();
        Task task = new Task("12345", "TaskName", "TaskDescription");

        taskService.addTask(task);
        taskService.updateTaskField("12345", "name", "UpdatedTaskName");
        taskService.updateTaskField("12345", "description", "UpdatedTaskDescription");

        assertEquals("UpdatedTaskName", taskService.getTask("12345").getName());
        assertEquals("UpdatedTaskDescription", taskService.getTask("12345").getDescription());
    }
}
