import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "Sample Address");

        contactService.addContact(contact);

        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "Sample Address");

        contactService.addContact(contact);
        contactService.deleteContact("12345");

        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testUpdateContactField() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "Sample Address");

        contactService.addContact(contact);
        contactService.updateContactField("12345", "firstName", "Jane");
        contactService.updateContactField("12345", "lastName", "Smith");
        contactService.updateContactField("12345", "phone", "9876543210");
        contactService.updateContactField("12345", "address", "New Address");

        assertEquals("Jane", contactService.getContact("12345").getFirstName());
        assertEquals("Smith", contactService.getContact("12345").getLastName());
        assertEquals("9876543210", contactService.getContact("12345").getPhone());
        assertEquals("New Address", contactService.getContact("12345").getAddress());
    }
}

