package test;
import main.Task;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

	 @Test
	    public void testTaskCreation() {
	        Task task = new Task("12345", "TaskName", "TaskDescription");

	        assertEquals("12345", task.getTaskId());
	        assertEquals("TaskName", task.getName());
	        assertEquals("TaskDescription", task.getDescription());
	    }

	    @Test
	    public void testTaskUpdate() {
	        Task task = new Task("12345", "TaskName", "TaskDescription");

	        task.setName("UpdatedTaskName");
	        task.setDescription("UpdatedTaskDescription");

	        assertEquals("UpdatedTaskName", task.getName());
	        assertEquals("UpdatedTaskDescription", task.getDescription());
	    }
	}