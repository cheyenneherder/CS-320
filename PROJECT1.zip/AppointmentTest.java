package test;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
import main.Appointment;
public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        Date appointmentDate = new Date();
        String appointmentId = "12345";
        String description = "Meeting";

        Appointment appointment = new Appointment(appointmentId, appointmentDate, description);

        assertEquals(appointmentId, appointment.getAppointmentId());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getDescription());
    }
}
